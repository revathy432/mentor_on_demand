package com.spring.demo.repository;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.spring.demo.model.CurrentTraining;
import com.spring.demo.model.User;

	@Repository
	public interface CurrentTrainingRepository extends CrudRepository<CurrentTraining, Integer> {

		List<CurrentTraining> findByUsername(User u);

}
