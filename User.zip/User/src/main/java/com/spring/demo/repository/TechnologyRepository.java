package com.spring.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.demo.model.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology, String> {
	List<Technology> findAll();

	Technology findByTechnology(String technology);

}
