package com.spring.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.demo.model.CompletedTraining;
import com.spring.demo.model.CurrentTraining;
import com.spring.demo.model.Value;
import com.spring.demo.model.Role;
import com.spring.demo.model.Technology;
import com.spring.demo.model.User;
import com.spring.demo.model.Userdata;
import com.spring.demo.repository.CompletedTrainingRepository;
import com.spring.demo.repository.CurrentTrainingRepository;
import com.spring.demo.repository.RoleRepository;
import com.spring.demo.repository.TechnologyRepository;
import com.spring.demo.repository.UserRepository;
import com.spring.demo.repository.UserdataRepository;
import com.spring.demo.repository.ValueRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private CompletedTrainingRepository completedRepository;
	@Autowired
	private UserdataRepository userdataRepository;
	@Autowired
	private CurrentTrainingRepository currentRepository;
	@Autowired
	private ValueRepository valueRepository;
	@Autowired
	private TechnologyRepository technologyRepository;
	public void saveUserdata(Userdata u) {
		userdataRepository.save(u);
		
		
	}
	public void saveRole(Role r) {
		roleRepository.save(r);
		
	}
	public void saveUser(String username,String password) {
		User u=new User();
		u.setUsername(username);
		u.setPassword(password);
		int id=1;
		Role r=roleRepository.findById(id);
		u.setRolename(r);
		
		userRepository.save(u);
		
	}
	public List<CompletedTraining> searchCompleted(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return completedRepository.findByUsername(u);
		
	}
	public List<CurrentTraining> searchCurrent(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return currentRepository.findByUsername(u);
		
	}
	public List<CompletedTraining> searchCompletedtraining() {
				
		
		return (List<CompletedTraining>) completedRepository.findAll();
		
	}
	public void saveUser(User u) {
		userRepository.save(u);
		// TODO Auto-generated method stub
		
	}
	public List<CurrentTraining> searchCurrenttraining() {
		// TODO Auto-generated method stub
		return (List<CurrentTraining>) currentRepository.findAll();
	}
	public List<Value> searchValue() {
		// TODO Auto-generated method stub
		return (List<Value>) valueRepository.findAll();
	}
	public User findUser(String username) {
		return userRepository.findByUsername(username);
		// TODO Auto-generated method stub
	}
	public void savecurrent(String username, String technology) {
		// TODO Auto-generated method stub
		Technology t=technologyRepository.findByTechnology(technology);
		User user=userRepository.findByUsername(username);
		CurrentTraining u=new CurrentTraining();
		u.setTechnology(t.getTechnology());
		u.setDuration("0Days");
		u.setUsername(user);
		currentRepository.save(u);
	}		
	}
	

