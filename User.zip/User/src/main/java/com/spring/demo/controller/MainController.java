package com.spring.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.demo.model.CompletedTraining;
import com.spring.demo.model.CurrentTraining;
import com.spring.demo.model.Value;
import com.spring.demo.model.Role;
import com.spring.demo.model.User;
import com.spring.demo.model.Userdata;
import com.spring.demo.repository.RoleRepository;
import com.spring.demo.service.UserService;

@Controller    
@CrossOrigin("http://localhost:4200")  

public class MainController {
	@Autowired
	private UserService userService;
	@Autowired
	private RoleRepository roleRepository;
	@PostMapping(path="/role")
	public @ResponseBody String role(@RequestBody Role r) {
		userService.saveRole(r);
		return "saved";
		
	}
	@GetMapping(path="/user/{username}/{password}")
	public @ResponseBody String user(@PathVariable String username,@PathVariable String password) {
		
		userService.saveUser(username,password);
		return "saved";
		
	}
	@GetMapping("/findcompleted/{username}")
	public @ResponseBody List<CompletedTraining>  findcompleted(@PathVariable String username){
		
     return userService.searchCompleted(username);
	}
	@GetMapping("/findcurrent/{username}")
	public @ResponseBody List<CurrentTraining>  findcurrent(@PathVariable String username){
		
     return userService.searchCurrent(username);
	}
	@PostMapping("/save")
	public @ResponseBody String saveUserdata(@RequestBody Userdata u){
		userService.saveUserdata(u);
		return "stored";
	}
	@GetMapping("/findcompletedtraining")
	public @ResponseBody List<CompletedTraining>  findcompletedtraining(){
		
     return userService.searchCompletedtraining();
	}
	@PostMapping("/saveuser")
	public @ResponseBody String saveUser(@RequestBody User u){
		userService.saveUser(u);
		return "stored";
	}
	@GetMapping("/findcurrenttraining")
	public @ResponseBody List<CurrentTraining> findcurrenttraining(){
		return userService.searchCurrenttraining();
	}
	@GetMapping("/findmain")
	public @ResponseBody List<Value> findValue(){
		return userService.searchValue();
	}
	@GetMapping("/finduser/{username}")
	public @ResponseBody User  finduser(@PathVariable String username){
		
return userService.findUser(username);
	}
	@GetMapping("/savecurrent/{username}/{technology}")
	public @ResponseBody String savecurrent(@PathVariable String username,@PathVariable String technology) {
		userService.savecurrent(username,technology);
		return "stored";
	}


}
