package com.spring.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Value {
	@Id
	private int id;
private String name;
private String experience;
private String technology;
private int fees;
private String duration;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getExperience() {
	return experience;
}
public void setExperience(String experience) {
	this.experience = experience;
}
public String getTechnology() {
	return technology;
}
public void setTechnology(String technology) {
	this.technology = technology;
}
public int getFees() {
	return fees;
}
public void setFees(int fees) {
	this.fees = fees;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
	
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

}
