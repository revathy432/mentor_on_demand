package com.spring.demo.repository;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.spring.demo.model.CompletedTraining;
import com.spring.demo.model.User;

	@Repository
	public interface CompletedTrainingRepository extends CrudRepository<CompletedTraining, Integer> {

		List<CompletedTraining> findByUsername(User u);

}
