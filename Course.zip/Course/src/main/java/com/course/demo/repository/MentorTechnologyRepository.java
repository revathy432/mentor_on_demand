package com.course.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.course.demo.model.MentorTechnology;
import com.course.demo.model.Mentordata;

@Repository

public interface MentorTechnologyRepository extends CrudRepository<MentorTechnology, Integer>{

	List<MentorTechnology> findByTechnology(String technology);




	MentorTechnology findByMentorname(Mentordata mentorname);






}
