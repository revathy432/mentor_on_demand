package com.course.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.course.demo.model.Mentordata;

@Repository
public interface MentordataRepository extends CrudRepository<Mentordata, Integer> {

	Mentordata findByUsername(String username);


}
