package com.course.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class MentorTime {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String timing;
	
	@ManyToOne
	@JoinColumn(name="mentorname")
	private Mentordata mentorname;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public Mentordata getMentorname() {
		return mentorname;
	}

	public void setMentorname(Mentordata mentorname) {
		this.mentorname = mentorname;
	}
	
	
	
	

}
