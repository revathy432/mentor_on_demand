package com.course.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.demo.model.MentorTechnology;
import com.course.demo.model.MentorTime;
import com.course.demo.model.Mentordata;
import com.course.demo.repository.MentorTechnologyRepository;
import com.course.demo.repository.MentorTimeRepository;
import com.course.demo.repository.MentordataRepository;
@Service
public class MentorService {
	@Autowired
	private MentorTechnologyRepository mentorTechnologyRepository;
	@Autowired
	private MentorTimeRepository mentorTimeRepository;
	@Autowired
	private MentordataRepository mentorRepository;
	
	
	
	public List<MentorTime> findtime(String time){
		return mentorTimeRepository.findByTiming(time);
		
	}
	public List<MentorTechnology> findtimesearch(String time){
		List<MentorTime> timing=mentorTimeRepository.findByTiming(time);
		List<MentorTechnology> tech =new ArrayList<MentorTechnology>();
		for(MentorTime t:timing) {
			tech.add(mentorTechnologyRepository.findByMentorname(t.getMentorname()));
			
			
		}
		return tech;
		
	}
	
	public List<MentorTechnology> findtechnology(String technology){
		return mentorTechnologyRepository.findByTechnology(technology);
		
	}
	
	public List<MentorTechnology>  findMentorlist(){
		return (List<MentorTechnology>) mentorTechnologyRepository.findAll();
	}
	
	
	
	public void saveTechnology(String username,String technology) {
		Mentordata m=mentorRepository.findByUsername(username);
		MentorTechnology mt=new MentorTechnology();
		mt.setMentorname(m);
		mt.setTechnology(technology);
		mentorTechnologyRepository.save(mt);
	}
	public void saveTime(String username,String time) {
		Mentordata m=mentorRepository.findByUsername(username);
		MentorTime mt=new MentorTime();
		mt.setMentorname(m);
		mt.setTiming(time);
		
		mentorTimeRepository.save(mt);
	}
	public Mentordata findMentor(String username) {
		return mentorRepository.findByUsername(username);
	}
	public MentorTechnology findSkill(String username) {
		Mentordata m=mentorRepository.findByUsername(username);
		return mentorTechnologyRepository.findByMentorname(m);
		// TODO Auto-generated method stub
	}
	

}
