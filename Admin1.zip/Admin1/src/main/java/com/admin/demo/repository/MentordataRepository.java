package com.admin.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.admin.demo.model.Mentordata;

@Repository
public interface MentordataRepository extends CrudRepository<Mentordata, String> {


}
