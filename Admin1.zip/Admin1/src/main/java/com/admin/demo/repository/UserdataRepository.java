package com.admin.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.admin.demo.model.Userdata;

@Repository
public interface UserdataRepository extends CrudRepository<Userdata, String>{

	
}
