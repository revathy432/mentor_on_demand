package com.admin.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.admin.demo.model.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology, String> {


}
