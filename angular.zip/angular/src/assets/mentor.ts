export class Mentor{
    username:string;
    password:string;
    contactnumber:number;
    technology:string;
    experience:string;
}