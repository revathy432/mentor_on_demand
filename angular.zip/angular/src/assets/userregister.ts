export class Userregister{
    username:string;
    password:string;
    rolename:Role;
   }
   export class Role{
       id:number;
       rolename:string;
   }