export class User{
    username:string;
    firstname:string;
    lastname:string;
    contactnumber:number;
    password:string;
}
export class Mentor{
    username:string;
    password:string;
    contactnumber:number;
    technology:string;
    experience:string;
}