import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorprofile',
  templateUrl: './mentorprofile.component.html',
  styleUrls: ['./mentorprofile.component.css']
})
export class MentorprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
