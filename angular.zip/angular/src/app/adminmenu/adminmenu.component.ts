import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { AdminService } from '../admin.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-adminmenu',
  templateUrl: './adminmenu.component.html',
  styleUrls: ['./adminmenu.component.css']
})
export class AdminmenuComponent implements OnInit {

  private payment=[];
  private user=[];
  private mentor=[];private technology=[];
  value:boolean=false;
  current:boolean=false;
  complete:boolean=false;
  displayaddtech:boolean=false;
  private tech:string;
  private duration:string;
  private username:string;
 
    constructor(private trainer:AdminService,private router:ActivatedRoute) { }
  
    ngOnInit() {
      this.username=this.router.snapshot.paramMap.get('username');

    }
  
  display(){
    this.value=false;
    this.complete=false;
    this.current=true;
    this.trainer.getTechnology()
    .subscribe(value =>this.technology=value as string[]);

  }
display1(){
    this.value=false;
    this.complete=true;
    this.current=false;
    this.trainer.getUser()
    .subscribe(data => this.user=data as string[]);
   this.trainer.getMentor()
   .subscribe(data => this.mentor=data as string[]);
  }
  display2(){
    this.value=true;
    this.complete=false;
    this.current=false;
    this.trainer.getPayment()
    .subscribe(data =>this.payment=data as string[]);
  }
  delete(username){
  
    this.trainer.userblock(username).subscribe();
      
  }
  unblock(username){
    this.trainer.userunblock(username).subscribe();
  }
  addtech(){
  this.displayaddtech=true;
  }
  savetechnology(){
    this.trainer.addtechnology(this.tech,this.duration).subscribe();
    this.displayaddtech=false;
  }
  
}
