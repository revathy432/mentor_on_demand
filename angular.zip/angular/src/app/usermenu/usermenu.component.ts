import { Component, OnInit } from '@angular/core';
import { ServiceService} from '../service.service';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-usermenu',
  templateUrl: './usermenu.component.html',
  styleUrls: ['./usermenu.component.css']
})
export class UsermenuComponent implements OnInit {
private trainers=[];
private com=[];
private teche=[];
private trainee=[];
tech:string;
username:string;
value:boolean=false;
current:boolean=false;
complete:boolean=false;
dtech:boolean=false;
  constructor(private trainer:ServiceService,private router:ActivatedRoute) { }

  ngOnInit() {
    this.username=this.router.snapshot.paramMap.get('username');
  }
  display(){
    this.value=true;
    this.current=false;
    this.complete=false;
    this.dtech=false;
      this.trainer.findMentor()
      .subscribe(data =>this.trainers=data as string[]);
    }
    display1(){
      this.value=false;
      this.complete=true;
      this.current=false;
      this.dtech=false;
      this.trainer.getCompleted(this.username)
      .subscribe(value =>this.com=value as string[]);
    }
    display2(){
      this.value=false;
      this.complete=false;
      this.current=true;
      this.dtech=false;
      this.trainer.getCurrent(this.username)
      .subscribe(value => this.teche=value as string[]);
    }
    search(){
      this.value=false;
      this.complete=false;
      this.current=false;
      this.dtech=true;
      this.trainer.searchMentor(this.tech)
      .subscribe(value =>this.trainee=value as string[]);
      this.trainer.searchMentortime(this.tech)
      .subscribe(value => this.trainee=value as string[]);
    }
    propose(technology){
      this.trainer.savecurrent(this.username,technology).subscribe();
    }
    }
    