import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorserviceService {

  constructor(private http:HttpClient) { }
  getMentorCompleted(username:string){
    return this.http.get(`http://localhost:8080/api/Mentor1/findcompleted/${username}`);
  
  }
  getCurrent(username:string){
    return this.http.get(`http://localhost:8080/api/Mentor1/findcurrent/${username}`);
  }
  createMentor(user:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/Mentor1/save`,user);
  }
createUserregister(userregister:object):Observable<object>{
  return this.http.post('http://localhost:8080/api/Mentor1/savementor',userregister);
}
getSkill(username:string){
  return this.http.get(`http://localhost:8080/api/Course/findskill/${username}`);
}
}
