import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
url:string="/assets/data.json";
url1:string="/assets/completed.json";
url2:string="/assets/value.json";
private baseUrl="http://localhost:8080/api";
  constructor(private http:HttpClient) { }
  getTrainer(){
   return this.http.get(this.url);
  }
  getTechnology(){
    return this.http.get(this.url1);
  }
  getPayment(){
    return this.http.get(this.url2);
  }
 getCompleted(username:string){
   return this.http.get(`http://localhost:8080/api/User/findcompleted/${username}`);
 }
 getCurrent(username:string){
  return this.http.get(`http://localhost:8080/api/User/findcurrent/${username}`);
}
getValue(){
  return this.http.get('http://localhost:8080/api/User/findmain');

}
getUser(username:string):Observable<any>{
  return this.http.get(`http://localhost:8080/api/User/finduser/${username}`);
}
  createUser(user:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/User/save`,user);
  }
createUserregister(userregister:object):Observable<object>{
  return this.http.post('http://localhost:8080/api/User/saveuser',userregister);
}
searchMentor(technology:string):Observable<any> {  
  return this.http.get(`http://localhost:8080/api/Course/findtechnology/${technology}`);  
}
findMentor():Observable<any> {  
  return this.http.get(`http://localhost:8080/api/Course/findmentorlist/`);  
}
searchMentortime(time:string):Observable<any> {  
  return this.http.get(`http://localhost:8080/api/Course/findtimesearch/${time}`);  
}
savecurrent(username:string,technology:string){
  return this.http.get(`http://localhost:8080/api/User/savecurrent/${username}/${technology}`); 
}

}

