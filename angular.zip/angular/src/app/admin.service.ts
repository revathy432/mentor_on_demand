import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }
getPayment(){
   return this.http.get(`http://localhost:8080/api/Admin1/findpayment`)
}
getUser(){
  return this.http.get('http://localhost:8080/api/Admin1/finduser')
}
getMentor(){
  return this.http.get('http://localhost:8080/api/Admin1/findmentor')
}
getTechnology():Observable<any> {  
  return this.http.get(`http://localhost:8080/api/Admin1/findadmintechnology`);  
}
userblock(username:string){
  return this.http.get(`http://localhost:8080/api/Admin1/userblock/${username}`);

}
userunblock(username:string){
  return this.http.get(`http://localhost:8080/api/Admin1/userunblock/${username}`);

}
addtechnology(technology:string,duration:string){
  return this.http.get(`http://localhost:8080/api/Admin1/savetechnology/${technology}/${duration}`);

}
}
