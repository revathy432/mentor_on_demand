import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Userregister, Role } from 'src/assets/userregister';
import { User } from 'src/assets/user';


@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {
// userregister:Userregister=new Userregister();
// username:string;
// password:string;
// firstname:string;
// lastname:string;
// contactnumber:number;
user: User = new User();
userregister:Userregister=new Userregister();
  submitted = false;
  private error=false;
  username:string;
password:string;

firstname:string;
lastname:string;
contactnumber:number;
role:Role=new Role();
private id=1;
private rolename="user";


  constructor(private trainer:ServiceService) { }

  ngOnInit() {
  }
  save() {
    if(this.username==null || this.password==null || this.firstname==null || this.lastname==null
      && this.contactnumber==null ){
        this.error=true;
      }
    else{
  this.user.username=this.username;
  
  this.user.firstname=this.firstname;
  this.user.lastname=this.lastname;
  this.user.contactnumber=this.contactnumber;
  this.role.id=this.id;
  this.role.rolename=this.rolename;
  this.userregister.rolename=this.role;
  
  
    this.trainer.createUser(this.user)
      .subscribe(data => console.log(data), error => console.log(error));
    

    this.userregister.username=this.username;
    this.userregister.password=this.password;
    this.trainer.createUserregister(this.userregister)
    .subscribe(data => console.log(data), error => console.log(error));
    this.submitted = true;
    this.error=false
  }
  }

//   newUser():void{
//     this.submitted=false;
//     this.user=new User();
//   }
// save(){
//   this.trainer.createUser(this.user)
//     .subscribe(data => console.log(data),error => console.log(error));
//     this.user=new User();
//  }
//  onSubmit(){
//    this.submitted=true;
//    this.save();
//  }
}
