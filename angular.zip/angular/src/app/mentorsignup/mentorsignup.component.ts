import { Component, OnInit } from '@angular/core';
import { Mentor } from 'src/assets/mentor';
import { MentorserviceService } from '../mentorservice.service';
import { Userregister, Role } from 'src/assets/userregister';

@Component({
  selector: 'app-mentorsignup',
  templateUrl: './mentorsignup.component.html',
  styleUrls: ['./mentorsignup.component.css']
})
export class MentorsignupComponent implements OnInit {
mentor: Mentor = new Mentor();
submitted=false;
userregister:Userregister=new Userregister();
  private error=false;
  username:string;
password:string;

experience:string;
technology:string;
contactnumber:number;
role:Role=new Role();
private id=2;
private rolename="mentor";

  constructor(private trainer:MentorserviceService) { }

  ngOnInit() {
  }
  save() {
    if(this.username==null || this.password==null || this.experience==null || this.experience==null
      && this.contactnumber==null ){
        this.error=true;
      }
    else{
  this.mentor.username=this.username;
  
  this.mentor.password=this.password;
  this.mentor.experience=this.experience;
  this.mentor.contactnumber=this.contactnumber;
  this.mentor.technology=this.technology;

  this.role.id=this.id;
  this.role.rolename=this.rolename;
  this.userregister.rolename=this.role;
  
  
    this.trainer.createMentor(this.mentor)
      .subscribe(data => console.log(data), error => console.log(error));
    

    this.userregister.username=this.username;
    this.userregister.password=this.password;
    this.trainer.createUserregister(this.userregister)
    .subscribe(data => console.log(data), error => console.log(error));
    this.submitted = true;
    this.error=false
  }
  }

//   newMentor():void{
//     this.submitted=false;
//     this.mentor=new Mentor();
//   }
// save(){
//   this.trainer.createMentor(this.mentor)
//     .subscribe(data => console.log(data),error => console.log(error));
//     this.mentor=new Mentor();
//  }
//  onSubmit(){
//    this.submitted=true;
//    this.save();
//  }
}
