import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { MentorserviceService } from '../mentorservice.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-mentormenu',
  templateUrl: './mentormenu.component.html',
  styleUrls: ['./mentormenu.component.css']
})
export class MentormenuComponent implements OnInit {
  private technology=[];
  private com=[];
  private skill=[];

  value:boolean=false;
  current:boolean=false;
  complete:boolean=false;
  username:string;
  

  constructor(private trainer:MentorserviceService,private router:ActivatedRoute) { }

  ngOnInit() {
    this.username=this.router.snapshot.paramMap.get('username');

  }
  display(){
    this.value=false;
    this.complete=true;
    this.current=false;
    this.trainer.getMentorCompleted(this.username)
    .subscribe(value =>this.technology=value as string[]);
  }
  display1(){
    this.value=false;
    this.complete=false;
    this.current=true;
    this.trainer.getCurrent(this.username
      )
    .subscribe(value =>this.com=value as string[]);
  }
  display2(){
    this.value=true;
    this.complete=false;
    this.current=false;
    this.trainer.getSkill(this.username).subscribe(value=>this.skill=value as string[]);
    console.log(this.skill);
  
  }
  }
  


