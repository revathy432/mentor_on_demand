package com.mentor.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentor.demo.model.MentorCompletedTraining;
import com.mentor.demo.model.MentorCurrentTraining;
import com.mentor.demo.model.Mentordata;
import com.mentor.demo.model.Role;
import com.mentor.demo.repository.MentorCompletedTrainingRepository;
import com.mentor.demo.repository.MentorCurrentTrainingRepository;
import com.mentor.demo.repository.MentordataRepository;
import com.mentor.demo.repository.RoleRepository;
import com.mentor.demo.repository.UserRepository;
import com.mentor.demo.model.User;

@Service
public class MentorService {
@Autowired
	public RoleRepository roleRepository;
@Autowired
public UserRepository userRepository;
@Autowired
public MentordataRepository mentordataRepository;
@Autowired
public MentorCurrentTrainingRepository mentorCurrentRepository;
@Autowired
public MentorCompletedTrainingRepository mentorCompletedRepository;
    public void saveRole(Role r) {
     roleRepository.save(r);
    }
    public void saveUser(String username,String password) {
		User u=new User();
		u.setUsername(username);
		u.setPassword(password);
		int id=2;
		Role r=roleRepository.findById(id);
		u.setRolename(r);
		
		userRepository.save(u);
		
	}
    public void saveMentordata(Mentordata u) {
    	mentordataRepository.save(u);
    }
  
    public List<MentorCompletedTraining> searchCompleted(String username) {
  		User u=userRepository.findByUsername(username);
  		
  		
  		return mentorCompletedRepository.findByUsername(u);
  		
  	}
    	public List<MentorCompletedTraining> searchMentorCompleted() {
		// TODO Auto-generated method stub
		return (List<MentorCompletedTraining>) mentorCompletedRepository.findAll();
	}
		public Mentordata findMentor(String username) {
				return mentordataRepository.findByUsername(username);
			}
			// TODO Auto-generated method stub
		public void saveUser(User u) {
			userRepository.save(u);
			// TODO Auto-generated method stub
			
		}
		public List<MentorCurrentTraining> searchCurrent(String username) {
			// TODO Auto-generated method stub
			User u=userRepository.findByUsername(username);
			
			
			return mentorCurrentRepository.findByUsername(u);
		
		}
		
		}
  	


