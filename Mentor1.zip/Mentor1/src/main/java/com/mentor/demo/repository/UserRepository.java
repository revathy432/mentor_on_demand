package com.mentor.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mentor.demo.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {


	User findByUsername(String username);


}
