package com.mentor.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mentor.demo.model.MentorCompletedTraining;
import com.mentor.demo.model.MentorCurrentTraining;
import com.mentor.demo.model.Mentordata;
import com.mentor.demo.repository.RoleRepository;
import com.mentor.demo.service.MentorService;
import com.mentor.demo.model.User;

 @Controller
 @CrossOrigin("http://localhost:4200")
public class MainController {
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private MentorService mentorService;

	@GetMapping(path="/user/{username}/{password}")
	public @ResponseBody String user(@PathVariable String username,@PathVariable String password) {
		
		mentorService.saveUser(username,password);
		return "saved";
		
	}
	@PostMapping("/save")
	public @ResponseBody String saveMentordata(@RequestBody Mentordata u){
		mentorService.saveMentordata(u);
		return "stored";
	}
	@PostMapping("/savementor")
	public @ResponseBody String saveUser(@RequestBody User u){
		mentorService.saveUser(u);
		return "stored";
	}
	@GetMapping("/findcompleted/{username}")
	public @ResponseBody List<MentorCompletedTraining>  findcompleted(@PathVariable String username){
		
return mentorService.searchCompleted(username);
	}
	@GetMapping("/findcurrent/{username}")
	public @ResponseBody List<MentorCurrentTraining>  findcurrent(@PathVariable String username){
		
return mentorService.searchCurrent(username);
	}

@GetMapping("/findmentorcompleted")
	public @ResponseBody List<MentorCompletedTraining> findmentorcompleted(){
	return mentorService.searchMentorCompleted();
}
@GetMapping("/findmentor/{username}")
public @ResponseBody Mentordata findMentor(@PathVariable String username) {
	return mentorService.findMentor(username);
}
}
