package com.mentor.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mentor.demo.model.MentorCompletedTraining;
import com.mentor.demo.model.User;

@Repository
public interface MentorCompletedTrainingRepository extends CrudRepository<MentorCompletedTraining, Integer>{

	List<MentorCompletedTraining> findByUsername(User u);

}
