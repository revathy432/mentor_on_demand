package com.app.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@EnableZuulProxy  // act as zuul proxy.
@EnableEurekaServer
@SpringBootApplication
public class Zuulgateway1Application {

	public static void main(String[] args) {
		SpringApplication.run(Zuulgateway1Application.class, args);
	}

}
